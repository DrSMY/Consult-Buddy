import React, { useState, useEffect } from 'react';
import { Patient, Gender, ActivityLevel, TreatmentPlan, User, FollowupData } from './types';
import { IdentityForm } from './components/IdentityForm';
import { PatientForm } from './components/PatientForm';
import { TreatmentForm } from './components/TreatmentForm';
import { PatientList } from './components/PatientList';
import { ProfileEdit } from './components/ProfileEdit';
import { SummaryReview } from './components/SummaryReview';
import { AuthPage } from './components/AuthPage';
import { SelectionPage } from './components/SelectionPage';
import { FollowupForm } from './components/FollowupForm';
import { generatePatientSummary, generatePatientGuide } from './services/gemini';
import { AuthService } from './services/auth';
import { CloudStorage } from './services/cloud';
import { generateId } from './utils/helpers';
import { LogOut, ShieldCheck, PenSquare, PlusCircle, Users, X, Menu, Cloud, RefreshCw, Loader2, User as UserIcon, Settings } from 'lucide-react';

const INITIAL_PATIENT: Patient = {
  id: '',
  bookingId: '',
  bookingTime: '',
  name: '',
  mobileNumber: '',
  age: '',
  gender: Gender.Female,
  height: '',
  weight: '',
  bmi: null,
  isPregnant: false,
  isBreastfeeding: false,
  previousGlp1Use: false,
  chronicIllnesses: '',
  medications: '',
  activityLevel: ActivityLevel.Sedentary,
  notes: '',
  dateAdded: ''
};

type AppStep = 'selection' | 'identity' | 'followup' | 'clinical' | 'treatment' | 'summary' | 'profile';

const DocSlimLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: '#14b8a6' }} />
        <stop offset="100%" style={{ stopColor: '#0d9488' }} />
      </linearGradient>
    </defs>
    <rect width="100" height="100" rx="24" fill="url(#logoGradient)" />
    <path d="M50 25V75M25 50H75" stroke="white" strokeWidth="12" strokeLinecap="round" />
  </svg>
);

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [currentPatient, setCurrentPatient] = useState<Patient>({
    ...INITIAL_PATIENT, 
    id: generateId(),
    dateAdded: new Date().toISOString()
  });
  const [currentStep, setCurrentStep] = useState<AppStep>('selection');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLoadingPatients, setIsLoadingPatients] = useState(false);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [showMobileList, setShowMobileList] = useState(false);

  useEffect(() => {
    const session = AuthService.getSession();
    if (session) setCurrentUser(session);
  }, []);

  useEffect(() => {
    const fetchCloudData = async () => {
      if (!currentUser) return;
      setIsLoadingPatients(true);
      try {
        const cloudPatients = await CloudStorage.getPatients(currentUser.id);
        setPatients(cloudPatients);
      } catch (e) { console.error(e); }
      finally { setIsLoadingPatients(false); }
    };
    fetchCloudData();
  }, [currentUser]);

  const savePatientState = async (patientData: Patient) => {
    if (!currentUser) return;
    const updatedPatients = [...patients];
    const exists = updatedPatients.findIndex(p => p.id === patientData.id);
    if (exists >= 0) updatedPatients[exists] = patientData;
    else updatedPatients.unshift(patientData);
    setPatients(updatedPatients);
    setIsSyncing(true);
    await CloudStorage.savePatients(currentUser.id, updatedPatients);
    setIsSyncing(false);
  };

  const handleFinalize = async () => {
    setIsGeneratingInsight(true);
    try {
      const summary = await generatePatientSummary(currentPatient);
      setAiInsight(summary);
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const finalPatientSnapshot = { 
        ...currentPatient, 
        aiSummary: summary
      };
      
      setCurrentPatient(finalPatientSnapshot);
      setCurrentStep('summary');
    } catch (error) { 
      console.error(error); 
    } finally { 
      setIsGeneratingInsight(false); 
    }
  };

  const handleEdit = (patient: Patient) => {
    setCurrentPatient(patient);
    setAiInsight(patient.aiSummary || null);
    if (patient.treatment?.medication) setCurrentStep('summary');
    else if (patient.isFollowup) setCurrentStep('followup');
    else setCurrentStep('identity');
    setShowMobileList(false);
  };

  const handleReset = () => {
    setCurrentPatient({ ...INITIAL_PATIENT, id: generateId(), dateAdded: new Date().toISOString() });
    setAiInsight(null);
    setCurrentStep('selection');
  };

  if (!currentUser) return <AuthPage onLoginSuccess={setCurrentUser} />;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans overflow-hidden">
      <header className="bg-white border-b h-16 flex items-center justify-between px-6 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <DocSlimLogo />
          <h1 className="text-xl font-bold tracking-tight">DOCSLIM</h1>
        </div>
        <div className="flex items-center gap-4">
          {isSyncing && <RefreshCw className="w-4 h-4 text-medical-500 animate-spin" />}
          <button onClick={() => setCurrentStep('profile')} className="text-sm font-medium hover:text-medical-600 transition-colors">
            {currentUser.name}
          </button>
          <button onClick={() => { AuthService.logout(); setCurrentUser(null); }} className="text-slate-400 hover:text-red-500"><LogOut className="w-5 h-5" /></button>
        </div>
      </header>
      <main className="flex-1 flex overflow-hidden">
        <aside className="w-80 border-r bg-white hidden lg:flex flex-col p-4 gap-4 overflow-hidden">
          <PatientList patients={patients} activePatientId={currentPatient.id} onEdit={handleEdit} aiInsight={aiInsight} loadingInsight={isGeneratingInsight} />
        </aside>
        <section className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-4xl mx-auto">
            {currentStep === 'selection' && (
              <SelectionPage 
                onNewPatient={() => {
                  setCurrentPatient({ ...INITIAL_PATIENT, id: generateId(), dateAdded: new Date().toISOString(), isFollowup: false });
                  setCurrentStep('identity');
                }} 
                onFollowup={() => {
                  setCurrentPatient({ ...INITIAL_PATIENT, id: generateId(), dateAdded: new Date().toISOString(), isFollowup: true });
                  setCurrentStep('followup');
                }} 
              />
            )}
            {currentStep === 'identity' && <IdentityForm currentPatient={currentPatient} onChange={setCurrentPatient} onNext={() => setCurrentStep('clinical')} onReset={handleReset} />}
            {currentStep === 'followup' && (
              <FollowupForm 
                currentPatient={currentPatient} 
                onChange={setCurrentPatient} 
                patients={patients}
                onNext={() => setCurrentStep('clinical')} 
                onBack={() => setCurrentStep('selection')} 
              />
            )}
            {currentStep === 'clinical' && <PatientForm currentPatient={currentPatient} onChange={setCurrentPatient} onNext={() => setCurrentStep('treatment')} onBack={() => setCurrentStep(currentPatient.isFollowup ? 'followup' : 'identity')} loading={isGeneratingInsight} />}
            {currentStep === 'treatment' && <TreatmentForm currentPatient={currentPatient} onUpdateTreatment={(t) => setCurrentPatient(p => ({...p, treatment: t}))} onBack={() => setCurrentStep('clinical')} onComplete={handleFinalize} currentUser={currentUser} />}
            {currentStep === 'summary' && <SummaryReview currentPatient={currentPatient} onConfirm={async () => { await savePatientState(currentPatient); handleReset(); }} onBack={() => setCurrentStep('treatment')} />}
            {currentStep === 'profile' && <ProfileEdit user={currentUser} onUpdate={setCurrentUser} onBack={() => setCurrentStep('selection')} />}
          </div>
        </section>
      </main>
    </div>
  );
};

export default App;