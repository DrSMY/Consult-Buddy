import { Patient } from '../types';

export const exportToCSV = (patients: Patient[], scope: string = 'All') => {
  if (patients.length === 0) return;

  const headers = [
    "Booking ID",
    "Booking Time",
    "Name",
    "Mobile Number",
    "Date Added",
    "Age",
    "Gender",
    "Height (cm)",
    "Weight (kg)",
    "BMI",
    "BMR (kcal)",
    "Maintenance Calories",
    "Weight Loss Calories",
    "Treatment Notes", // Manual raw notes
    "Blood Test Required", // Flag
    "Medication Prescribed", // Combined Med + Dose
    "Clinical Summary", // AI generated clinical summary
    "Doctor Note and Suggestions", // Formatted Clinical Note
    "Patient Guide & Findings", // AI Guide
    "Follow-up Date" // Calculated 3 weeks from dateAdded
  ];

  const rows = patients.map(p => {
    const treatment = p.treatment;
    
    // Combine Medication and Dose
    const medName = treatment?.medication === 'Other' 
      ? (treatment.otherDetail || 'Other') 
      : (treatment?.medication || 'Pending');
    const dose = treatment?.dose || '';
    const prescribedMedication = dose ? `${medName} ${dose}` : medName;

    // Calculate Follow-up Date (21 days from dateAdded)
    const encounterDate = new Date(p.dateAdded);
    const followUpDate = new Date(encounterDate);
    followUpDate.setDate(encounterDate.getDate() + 21);
    const followUpStr = followUpDate.toLocaleDateString();

    return [
      `"${p.bookingId}"`,
      `"${p.bookingTime || ''}"`,
      `"${p.name}"`,
      `"${p.mobileNumber}"`,
      `"${encounterDate.toLocaleDateString()}"`,
      p.age,
      p.gender,
      p.height,
      p.weight,
      p.bmi?.toFixed(1),
      p.bmr ? Math.round(p.bmr) : '',
      p.dailyCalories ? Math.round(p.dailyCalories) : '',
      p.weightLossCalories ? Math.round(p.weightLossCalories) : '',
      `"${(treatment?.notes || '').replace(/"/g, '""')}"`,
      treatment?.bloodTestRequired ? "YES" : "NO",
      `"${prescribedMedication}"`,
      `"${(p.aiSummary || '').replace(/"/g, '""')}"`,
      `"${(treatment?.doctorSuggestions || '').replace(/"/g, '""')}"`,
      `"${(treatment?.patientGuide || '').replace(/"/g, '""')}"`,
      `"${followUpStr}"`
    ];
  });

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const dateStr = new Date().toISOString().split('T')[0];
  const capitalizedScope = scope.charAt(0).toUpperCase() + scope.slice(1);
  link.setAttribute('download', `DocSlim_Treatment_Report_${capitalizedScope}_${dateStr}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};