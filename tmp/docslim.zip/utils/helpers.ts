
export const generateId = (): string => {
  // Try to use native crypto if available and secure
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    try {
      return crypto.randomUUID();
    } catch (e) {
      // Fallback if context is not secure
    }
  }
  // Fallback timestamp + random string generator
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};
