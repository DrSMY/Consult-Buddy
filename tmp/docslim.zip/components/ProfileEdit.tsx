import React, { useState } from 'react';
import { User } from '../types';
import { AuthService } from '../services/auth';
// Added RefreshCw to the imports from lucide-react
import { User as UserIcon, Mail, Phone, Lock, Save, ArrowLeft, CheckCircle2, RefreshCw } from 'lucide-react';

interface ProfileEditProps {
  user: User;
  onUpdate: (user: User) => void;
  onBack: () => void;
}

export const ProfileEdit: React.FC<ProfileEditProps> = ({ user, onUpdate, onBack }) => {
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phoneNumber: user.phoneNumber,
    password: '' // Optional password update
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);
    
    const updates: Partial<User> = {
      name: formData.name,
      email: formData.email,
      phoneNumber: formData.phoneNumber
    };
    
    if (formData.password) {
      updates.password = formData.password;
    }

    const result = await AuthService.updateProfile(user.id, updates);
    if (result.success && result.user) {
      onUpdate(result.user);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    }
    setLoading(false);
  };

  return (
    <div className="bg-white rounded-[2rem] shadow-xl border border-slate-200 overflow-hidden flex flex-col h-full animate-slide-up">
      <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <h2 className="text-xl font-bold text-slate-900">Edit Profile</h2>
        </div>
      </div>

      <div className="p-8 overflow-y-auto flex-1 custom-scrollbar">
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto space-y-6">
          {success && (
            <div className="bg-emerald-50 border border-emerald-100 text-emerald-700 p-4 rounded-2xl flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5" />
              <p className="text-sm font-bold">Profile updated successfully!</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <UserIcon className="w-4 h-4 text-slate-400" /> Full Name
              </label>
              <input
                type="text"
                className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400" /> Email Address
              </label>
              <input
                type="email"
                className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-400" /> Phone Number
              </label>
              <input
                type="tel"
                className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                value={formData.phoneNumber}
                onChange={e => setFormData({ ...formData, phoneNumber: e.target.value })}
                required
              />
            </div>

            <div className="pt-4 border-t border-slate-100">
              <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                <Lock className="w-4 h-4 text-slate-400" /> New Password (Optional)
              </label>
              <input
                type="password"
                className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                placeholder="Leave blank to keep current password"
                value={formData.password}
                onChange={e => setFormData({ ...formData, password: e.target.value })}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-medical-600 text-white py-4 rounded-2xl font-bold hover:bg-medical-700 disabled:opacity-50 transition-all shadow-xl shadow-medical-600/20 flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            {loading ? 'Saving Changes...' : 'Save Profile Changes'}
          </button>
        </form>
      </div>
    </div>
  );
};