import React, { useState } from 'react';
import { Patient } from '../types';
import { Check, ArrowLeft, Copy, ClipboardCheck, FileText, User, Activity, Utensils, Zap, ThermometerSnowflake } from 'lucide-react';

interface SummaryReviewProps {
  currentPatient: Patient;
  onConfirm: () => void;
  onBack: () => void;
}

export const SummaryReview: React.FC<SummaryReviewProps> = ({ 
  currentPatient, 
  onConfirm, 
  onBack 
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string | undefined, section: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="bg-white rounded-[2rem] shadow-xl border border-slate-200 overflow-hidden flex flex-col h-full animate-slide-up">
      {/* Header */}
      <div className="px-8 py-6 border-b border-slate-100 bg-medical-900 flex justify-between items-center text-white">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-medical-800 rounded-xl transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl font-bold">Final Encounter Report</h2>
            <p className="text-xs text-medical-200/80 font-medium">Verify clinical and patient-facing details</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-[10px] font-bold bg-medical-700/50 px-3 py-1 rounded-full border border-medical-600/50 uppercase tracking-widest">Ready for Export</span>
        </div>
      </div>

      <div className="p-8 overflow-y-auto flex-1 custom-scrollbar bg-slate-50/30">
        <div className="max-w-4xl mx-auto space-y-10">
          
          {/* SECTION 1: CLINICAL RECORD (For the Doctor) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-medical-100 rounded-lg">
                  <FileText className="w-4 h-4 text-medical-600" />
                </div>
                <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">Clinical Record & Suggestions</h3>
              </div>
              <button 
                onClick={() => handleCopy(`${currentPatient.aiSummary}\n\nCLINICAL SUGGESTION:\n${currentPatient.treatment?.doctorSuggestions}`, 'clinical')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all ${copiedSection === 'clinical' ? 'bg-emerald-500 text-white' : 'bg-white text-medical-600 border border-medical-200 hover:border-medical-400 shadow-sm'}`}
              >
                {copiedSection === 'clinical' ? <ClipboardCheck className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedSection === 'clinical' ? 'Copied' : 'Copy Record'}
              </button>
            </div>
            
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-200 space-y-6">
              <div className="prose prose-sm prose-slate max-w-none">
                <div className="whitespace-pre-wrap text-slate-700 font-medium text-[13px] leading-relaxed">
                  {currentPatient.aiSummary}
                </div>
              </div>
              
              <div className="pt-6 border-t border-slate-100">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Clinical Suggestion (Doctor's Note)</h4>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-[12px] font-mono text-slate-600 whitespace-pre-wrap leading-relaxed">
                  {currentPatient.treatment?.doctorSuggestions || 'No suggestions recorded.'}
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: PATIENT CARE GUIDE (For the Patient) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-emerald-100 rounded-lg">
                  <User className="w-4 h-4 text-emerald-600" />
                </div>
                <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">Patient-Centered Care Guide</h3>
              </div>
              <button 
                onClick={() => handleCopy(currentPatient.treatment?.patientGuide, 'guide')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all ${copiedSection === 'guide' ? 'bg-emerald-500 text-white' : 'bg-white text-emerald-600 border border-emerald-200 hover:border-emerald-400 shadow-sm'}`}
              >
                {copiedSection === 'guide' ? <ClipboardCheck className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedSection === 'guide' ? 'Copied' : 'Copy Guide'}
              </button>
            </div>
            
            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                 <Activity className="w-40 h-40" />
              </div>
              
              <div className="flex flex-wrap gap-4 mb-8">
                 <div className="flex items-center gap-2 bg-blue-50 px-3 py-1.5 rounded-full border border-blue-100">
                    <Activity className="w-3.5 h-3.5 text-blue-500" />
                    <span className="text-[10px] font-bold text-blue-700 uppercase">Weekly Injection</span>
                 </div>
                 <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
                    <Utensils className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-[10px] font-bold text-emerald-700 uppercase">High Protein Plan</span>
                 </div>
                 <div className="flex items-center gap-2 bg-orange-50 px-3 py-1.5 rounded-full border border-orange-100">
                    <Zap className="w-3.5 h-3.5 text-orange-500" />
                    <span className="text-[10px] font-bold text-orange-700 uppercase">TDEE Focused</span>
                 </div>
                 <div className="flex items-center gap-2 bg-cyan-50 px-3 py-1.5 rounded-full border border-cyan-100">
                    <ThermometerSnowflake className="w-3.5 h-3.5 text-cyan-500" />
                    <span className="text-[10px] font-bold text-cyan-700 uppercase">Refrigerated Storage</span>
                 </div>
              </div>

              <div className="prose prose-slate max-w-none">
                <div className="whitespace-pre-wrap text-slate-700 font-medium text-[13px] leading-relaxed">
                  {currentPatient.treatment?.patientGuide || 'Patient guide not yet generated.'}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-100 p-5 rounded-3xl flex items-start gap-4">
             <div className="p-2 bg-amber-100 rounded-xl shrink-0">
                <Check className="w-5 h-5 text-amber-600" />
             </div>
             <div>
                <p className="text-xs text-amber-900 font-bold mb-1 uppercase tracking-wider">Ready to Finalize?</p>
                <p className="text-[11px] text-amber-800 font-medium leading-relaxed">
                  Confirming will permanently save this record to the cloud. You can copy the sections above to your primary EMR or provide the care guide directly to {currentPatient.name}.
                </p>
             </div>
          </div>
        </div>
      </div>

      <div className="p-6 border-t border-slate-100 bg-white flex justify-between items-center px-8">
         <button onClick={onBack} className="text-slate-500 hover:text-slate-800 px-6 py-3 rounded-2xl font-bold transition-colors flex items-center gap-2 text-sm group">
           <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" /> Back to Treatment
         </button>
         <button onClick={onConfirm} className="bg-medical-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-medical-700 transition-all shadow-xl shadow-medical-600/20 active:scale-95 flex items-center gap-3 text-sm">
           Confirm & Save Encounter
           <Check className="w-5 h-5" />
         </button>
      </div>
    </div>
  );
};