import React, { useState } from 'react';
import { Patient, Gender } from '../types';
import { CircleUser, Phone, Clock, Wand2, ArrowRight, RefreshCw, Ruler, Weight as WeightIcon, CalendarDays } from 'lucide-react';
import { parsePatientNotes } from '../services/gemini';

interface IdentityFormProps {
  currentPatient: Patient;
  onChange: (patient: Patient) => void;
  onNext: () => void;
  onReset: () => void;
}

export const IdentityForm: React.FC<IdentityFormProps> = ({ 
  currentPatient, 
  onChange, 
  onNext, 
  onReset
}) => {
  const [smartInput, setSmartInput] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft'>('cm');
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lbs'>('kg');

  const handleInputChange = (field: keyof Patient, value: any) => {
    onChange({ ...currentPatient, [field]: value });
  };

  const handleSmartFill = async () => {
    if (!smartInput.trim()) return;
    setIsParsing(true);
    const extractedData = await parsePatientNotes(smartInput);
    
    const updated = { ...currentPatient };
    if (extractedData.name) updated.name = extractedData.name;
    if (extractedData.mobileNumber) updated.mobileNumber = extractedData.mobileNumber;
    if (extractedData.bookingTime) updated.bookingTime = extractedData.bookingTime;
    if (extractedData.age) updated.age = extractedData.age;
    if (extractedData.gender) updated.gender = extractedData.gender as Gender;
    
    if (extractedData.height) updated.height = extractedData.height;
    if (extractedData.weight) updated.weight = extractedData.weight;
    if (extractedData.chronicIllnesses) updated.chronicIllnesses = extractedData.chronicIllnesses;
    if (extractedData.medications) updated.medications = extractedData.medications;
    if (extractedData.isPregnant !== undefined) updated.isPregnant = extractedData.isPregnant;
    if (extractedData.isBreastfeeding !== undefined) updated.isBreastfeeding = extractedData.isBreastfeeding;
    
    updated.notes = (updated.notes ? updated.notes + '\n\n' : '') + `[Raw Input]: ${smartInput}`;
    
    onChange(updated);
    setIsParsing(false);
    setSmartInput('');
  };
  
  const isFormValid = currentPatient.name && 
                      currentPatient.mobileNumber && 
                      currentPatient.age && 
                      currentPatient.height && 
                      currentPatient.weight;

  return (
    <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/60 border border-slate-200 overflow-hidden flex flex-col h-full transition-all">
      {/* Header with Step Indicator */}
      <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-medical-600 text-white font-bold text-lg shadow-lg shadow-medical-600/20">1</div>
            <div className="ml-4">
              <h2 className="text-base font-bold text-slate-900 leading-none">Identity</h2>
              <p className="text-xs font-medium text-slate-500 mt-1">Demographics</p>
            </div>
          </div>
          <div className="h-px w-10 bg-slate-200"></div>
          <div className="flex items-center opacity-40">
            <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-slate-200 text-slate-500 font-bold text-lg">2</div>
          </div>
          <div className="h-px w-10 bg-slate-200"></div>
          <div className="flex items-center opacity-40">
            <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-slate-200 text-slate-500 font-bold text-lg">3</div>
          </div>
        </div>
        <button 
          onClick={onReset}
          className="p-2.5 text-slate-400 hover:text-medical-600 hover:bg-medical-50 rounded-xl transition-all"
          title="Reset Form"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>
      
      <div className="p-8 overflow-y-auto flex-1 custom-scrollbar">
        
        {/* Smart Fill Section */}
        <div className="mb-10 group">
          <div className="bg-medical-50/50 p-6 rounded-3xl border border-medical-100 transition-all hover:bg-medical-50 group-focus-within:ring-2 ring-medical-500/10">
            <label className="block text-sm font-bold text-medical-800 mb-3 flex items-center gap-2">
              <Wand2 className="w-4 h-4 text-medical-600" />
              AI Smart Fill
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input 
                type="text" 
                placeholder="Ahmed Ali, 0501234567, 35y Male, 180cm, 95kg..."
                className="flex-1 rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 bg-white transition-all outline-none"
                value={smartInput}
                onChange={(e) => setSmartInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSmartFill()}
              />
              <button 
                onClick={handleSmartFill}
                disabled={isParsing || !smartInput}
                className="bg-medical-600 text-white px-6 py-3.5 rounded-xl text-sm font-bold hover:bg-medical-700 disabled:opacity-50 transition-all shadow-lg shadow-medical-600/20 active:scale-95 flex items-center justify-center gap-2"
              >
                {isParsing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                {isParsing ? 'Parsing...' : 'Auto-Fill'}
              </button>
            </div>
            <p className="text-[10px] text-medical-600/60 mt-3 font-medium uppercase tracking-wider">Paste raw patient data here to extract details instantly</p>
          </div>
        </div>

        <div className="space-y-8 max-w-2xl mx-auto">
            {/* Identity */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                   <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                     <CalendarDays className="w-4 h-4 text-slate-400" /> Booking Ref
                   </label>
                   <input 
                     type="text"
                     className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                     value={currentPatient.bookingId}
                     onChange={(e) => handleInputChange('bookingId', e.target.value)}
                     placeholder="e.g. #12345"
                   />
                </div>
                <div className="space-y-2">
                   <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                     <Clock className="w-4 h-4 text-slate-400" /> Appointment Time
                   </label>
                   <input 
                     type="time"
                     className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                     value={currentPatient.bookingTime || ''}
                     onChange={(e) => handleInputChange('bookingTime', e.target.value)}
                   />
                </div>

              <div className="sm:col-span-2 space-y-2">
                <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                  <CircleUser className="w-4 h-4 text-slate-400" /> Full Name <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text"
                  className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                  value={currentPatient.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Patient Full Name"
                />
              </div>

              <div className="sm:col-span-2 space-y-2">
                <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-slate-400" /> Mobile Number <span className="text-red-500">*</span>
                </label>
                <input 
                  type="tel"
                  className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                  value={currentPatient.mobileNumber}
                  onChange={(e) => handleInputChange('mobileNumber', e.target.value)}
                  placeholder="+971..."
                />
              </div>

                <div className="space-y-2">
                  <label className="block text-sm font-bold text-slate-700">Age <span className="text-red-500">*</span></label>
                  <input 
                    type="number"
                    className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none"
                    value={currentPatient.age}
                    onChange={(e) => handleInputChange('age', e.target.value === '' ? '' : Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-bold text-slate-700">Gender <span className="text-red-500">*</span></label>
                  <select 
                    className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none bg-white"
                    value={currentPatient.gender}
                    onChange={(e) => handleInputChange('gender', e.target.value as Gender)}
                  >
                    <option value={Gender.Male}>Male</option>
                    <option value={Gender.Female}>Female</option>
                    <option value={Gender.Other}>Other</option>
                  </select>
                </div>
            </div>

            {/* Anthropometrics */}
            <div className="pt-8 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                      <Ruler className="w-4 h-4 text-slate-400" /> Height <span className="text-red-500">*</span>
                    </label>
                    <div className="flex bg-slate-100 rounded-lg p-1 text-[10px] font-bold">
                      <button type="button" onClick={() => setHeightUnit('cm')} className={`px-2.5 py-1 rounded-md transition-all ${heightUnit === 'cm' ? 'bg-white shadow-sm text-medical-600' : 'text-slate-500 hover:text-slate-700'}`}>CM</button>
                      <button type="button" onClick={() => setHeightUnit('ft')} className={`px-2.5 py-1 rounded-md transition-all ${heightUnit === 'ft' ? 'bg-white shadow-sm text-medical-600' : 'text-slate-500 hover:text-slate-700'}`}>FT</button>
                    </div>
                  </div>
                  
                  {heightUnit === 'cm' ? (
                    <div className="relative">
                      <input type="number" className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none" value={currentPatient.height} onChange={(e) => handleInputChange('height', e.target.value === '' ? '' : Number(e.target.value))} />
                      <span className="absolute right-4 top-3.5 text-slate-400 text-xs font-bold">cm</span>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <input type="number" className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none" value={currentPatient.height ? Math.floor(currentPatient.height / 30.48) : ''} onChange={(e) => {
                          const newFt = Number(e.target.value);
                          const currentIn = currentPatient.height ? Math.round((currentPatient.height / 2.54) % 12) : 0;
                          handleInputChange('height', ((newFt * 12) + currentIn) * 2.54);
                        }} />
                        <span className="absolute right-3 top-3.5 text-slate-400 text-xs font-bold">ft</span>
                      </div>
                      <div className="relative flex-1">
                        <input type="number" className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none" value={currentPatient.height ? Math.round((currentPatient.height / 2.54) % 12) : ''} onChange={(e) => {
                          const newIn = Number(e.target.value);
                          const currentFt = currentPatient.height ? Math.floor(currentPatient.height / 30.48) : 0;
                          handleInputChange('height', ((currentFt * 12) + newIn) * 2.54);
                        }} />
                        <span className="absolute right-3 top-3.5 text-slate-400 text-xs font-bold">in</span>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                   <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                      <WeightIcon className="w-4 h-4 text-slate-400" /> Weight <span className="text-red-500">*</span>
                    </label>
                    <div className="flex bg-slate-100 rounded-lg p-1 text-[10px] font-bold">
                      <button type="button" onClick={() => setWeightUnit('kg')} className={`px-2.5 py-1 rounded-md transition-all ${weightUnit === 'kg' ? 'bg-white shadow-sm text-medical-600' : 'text-slate-500 hover:text-slate-700'}`}>KG</button>
                      <button type="button" onClick={() => setWeightUnit('lbs')} className={`px-2.5 py-1 rounded-md transition-all ${weightUnit === 'lbs' ? 'bg-white shadow-sm text-medical-600' : 'text-slate-500 hover:text-slate-700'}`}>LBS</button>
                    </div>
                  </div>
                  <div className="relative">
                    <input type="number" className="w-full rounded-xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-3.5 border transition-all outline-none" value={currentPatient.weight === '' ? '' : weightUnit === 'kg' ? currentPatient.weight : (Number(currentPatient.weight) * 2.20462).toFixed(1)} onChange={(e) => {
                      const val = e.target.value;
                      if (val === '') handleInputChange('weight', '');
                      else {
                        const num = Number(val);
                        handleInputChange('weight', weightUnit === 'kg' ? num : num / 2.20462);
                      }
                    }} />
                    <span className="absolute right-4 top-3.5 text-slate-400 text-xs font-bold uppercase">{weightUnit}</span>
                  </div>
                </div>
            </div>
        </div>
      </div>

      <div className="px-8 py-6 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-4 justify-between items-center">
         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
             Step 1 of 3: Verification
         </span>
         <button 
           onClick={onNext}
           disabled={!isFormValid}
           className="w-full sm:w-auto bg-medical-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-medical-700 disabled:opacity-50 transition-all shadow-xl shadow-medical-600/25 active:scale-95 flex items-center justify-center gap-3"
         >
           Save & Analysis
           <ArrowRight className="w-5 h-5" />
         </button>
      </div>
    </div>
  );
};