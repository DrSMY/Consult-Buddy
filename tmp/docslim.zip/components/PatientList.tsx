
import React, { useState } from 'react';
import { Patient } from '../types';
import { FileDown, User, Activity, FileSearch, Clock, Search, X, ChevronRight, Copy, Check } from 'lucide-react';
import { exportToCSV } from '../utils/csv';

interface PatientListProps {
  patients: Patient[];
  activePatientId?: string;
  onEdit: (patient: Patient) => void;
  aiInsight: string | null;
  loadingInsight: boolean;
}

type ViewMode = 'day' | 'week' | 'month' | 'all';

export const PatientList: React.FC<PatientListProps> = ({ 
  patients, 
  activePatientId, 
  onEdit,
  aiInsight,
  loadingInsight
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('day');
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!aiInsight) return;
    navigator.clipboard.writeText(aiInsight);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getFilteredPatients = () => {
    if (searchTerm.trim()) {
      const lowerTerm = searchTerm.toLowerCase();
      return patients.filter(p => 
        p.name.toLowerCase().includes(lowerTerm) ||
        p.mobileNumber.includes(lowerTerm) ||
        p.bookingId.toLowerCase().includes(lowerTerm)
      );
    }

    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    return patients.filter(p => {
      if (viewMode === 'all') return true;
      const date = new Date(p.dateAdded);
      if (viewMode === 'day') return date >= startOfDay;
      if (viewMode === 'week') return date >= new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      if (viewMode === 'month') return date >= new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      return true;
    });
  };

  const filteredPatients = getFilteredPatients();

  return (
    <div className="flex flex-col h-full gap-4 overflow-hidden">
      
      {/* Summarizer Panel */}
      <div className={`bg-medical-900 rounded-3xl shadow-xl shadow-medical-900/10 overflow-hidden flex flex-col min-h-[160px] shrink-0 border transition-all ${aiInsight ? 'border-medical-400/50 ring-2 ring-medical-500/20' : 'border-medical-800'}`}>
        <div className="p-4 bg-medical-800/50 flex items-center justify-between">
           <div className="flex items-center gap-2.5">
             <div className="p-1.5 bg-medical-500/20 rounded-lg">
               <FileSearch className="w-4 h-4 text-medical-200" />
             </div>
             <h2 className="font-bold text-medical-50 text-xs tracking-wider uppercase">Summarizer</h2>
           </div>
           <div className="flex items-center gap-2">
             {aiInsight && !loadingInsight && (
               <button 
                 onClick={handleCopy}
                 className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-medical-700 text-medical-100 hover:bg-medical-600'}`}
               >
                 {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                 {copied ? 'Copied' : 'Copy'}
               </button>
             )}
             {loadingInsight && <div className="flex gap-1"><div className="w-1 h-1 bg-medical-400 rounded-full animate-bounce"></div><div className="w-1 h-1 bg-medical-400 rounded-full animate-bounce [animation-delay:0.2s]"></div><div className="w-1 h-1 bg-medical-400 rounded-full animate-bounce [animation-delay:0.4s]"></div></div>}
           </div>
        </div>
        <div className="p-4 flex-1 overflow-y-auto custom-scrollbar text-[11px] text-medical-200/90 leading-relaxed font-medium">
           {loadingInsight ? (
             <div className="space-y-3 opacity-50">
               <div className="h-1.5 bg-medical-700 rounded-full w-4/5"></div>
               <div className="h-1.5 bg-medical-700 rounded-full w-full"></div>
               <div className="h-1.5 bg-medical-700 rounded-full w-2/3"></div>
             </div>
           ) : aiInsight ? (
             <div className="prose prose-sm prose-invert max-w-none whitespace-pre-wrap">
               {aiInsight}
             </div>
           ) : (
             <div className="flex flex-col items-center justify-center py-4 gap-2 opacity-40">
               <Activity className="w-6 h-6" />
               <p className="italic text-center">Complete treatment for summary...</p>
             </div>
           )}
        </div>
      </div>

      {/* Patient List Container */}
      <div className="bg-white rounded-[2rem] shadow-lg shadow-slate-200/50 border border-slate-200 overflow-hidden flex flex-col flex-1">
        <div className="p-5 border-b border-slate-100 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <h2 className="font-extrabold text-slate-900 text-sm tracking-tight">ENCOUNTERS</h2>
            <button 
              onClick={() => exportToCSV(filteredPatients, searchTerm ? 'Search' : viewMode)}
              disabled={filteredPatients.length === 0}
              className="p-2 text-medical-600 hover:bg-medical-50 rounded-xl transition-all disabled:opacity-30"
            >
              <FileDown className="w-5 h-5" />
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Quick find..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 rounded-xl border-slate-100 bg-slate-50 focus:bg-white focus:border-medical-500 transition-all text-xs outline-none"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500"><X className="w-3.5 h-3.5" /></button>
            )}
          </div>
          
          {!searchTerm && (
            <div className="flex bg-slate-100 p-1 rounded-xl">
               {[
                 { id: 'day', label: 'Today', icon: Clock },
                 { id: 'week', label: 'Week', icon: User },
                 { id: 'all', label: 'All', icon: User }
               ].map((tab) => {
                 const isActive = viewMode === tab.id;
                 const Icon = tab.icon;
                 return (
                   <button
                     key={tab.id}
                     onClick={() => setViewMode(tab.id as ViewMode)}
                     className={`flex-1 flex items-center justify-center gap-2 py-2 text-[10px] font-bold rounded-lg transition-all ${
                       isActive ? 'bg-white text-medical-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'
                     }`}
                   >
                     <Icon className={`w-3.5 h-3.5`} />
                     {tab.label}
                   </button>
                 );
               })}
            </div>
          )}
        </div>
        
        <div className="overflow-y-auto flex-1 p-3 space-y-2 custom-scrollbar">
          {filteredPatients.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-slate-300 gap-2">
               <User className="w-8 h-8 opacity-20" />
               <p className="text-[10px] font-bold uppercase tracking-wider">No records found</p>
            </div>
          ) : (
            filteredPatients.map(patient => (
              <div 
                key={patient.id}
                onClick={() => onEdit(patient)}
                className={`group p-4 rounded-2xl border transition-all cursor-pointer relative ${
                  activePatientId === patient.id 
                    ? 'bg-medical-50/50 border-medical-200 ring-1 ring-medical-100' 
                    : 'bg-white border-slate-50 hover:bg-slate-50 hover:border-slate-200'
                }`}
              >
                <div className="flex justify-between items-start">
                   <h3 className="font-bold text-slate-900 text-xs truncate max-w-[140px]">{patient.name}</h3>
                   <div className="flex items-center gap-1.5 text-[9px] font-extrabold text-slate-400 bg-slate-100/50 px-2 py-0.5 rounded-full uppercase tracking-tighter">
                     <Clock className="w-2.5 h-2.5" />
                     {new Date(patient.dateAdded).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                   </div>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 font-bold mt-2">
                   <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 uppercase tracking-tighter">{patient.gender.charAt(0)}</span>
                   <span>{patient.age}y</span>
                   <span className={`px-1.5 py-0.5 rounded-md ${patient.bmi && patient.bmi >= 30 ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                      BMI {patient.bmi ? patient.bmi.toFixed(1) : '-'}
                   </span>
                </div>
                {patient.treatment?.medication && (
                  <div className="text-[9px] font-extrabold text-medical-700 bg-medical-50 px-2 py-1 rounded-lg border border-medical-100 inline-flex items-center gap-1.5 mt-3 uppercase tracking-wider">
                    <Activity className="w-3 h-3" />
                    {patient.treatment.medication} {patient.treatment.dose}
                  </div>
                )}
                <ChevronRight className={`absolute right-3 bottom-4 w-4 h-4 text-slate-300 transition-transform ${activePatientId === patient.id ? 'translate-x-0 opacity-100' : '-translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100'}`} />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
