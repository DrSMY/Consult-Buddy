import React, { useState } from 'react';
import { AuthService } from '../services/auth';
import { User } from '../types';
import { ArrowRight, UserPlus, LogIn, Lock, User as UserIcon, AlertCircle, Mail, Phone } from 'lucide-react';

interface AuthPageProps {
  onLoginSuccess: (user: User) => void;
}

// Reusing DocSlim Logo for Auth Page to ensure consistency
const DocSlimLogoLarge = ({ className = "w-16 h-16" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="100" height="100" rx="20" className="fill-medical-600" />
    <path d="M50 25V75M25 50H75" stroke="white" strokeWidth="12" strokeLinecap="round" />
    <path 
      d="M25 30C25 30 35 40 35 50C35 60 25 70 25 70" 
      stroke="#ccfbf1" 
      strokeWidth="6" 
      strokeLinecap="round"
      opacity="0.9"
    />
    <path 
      d="M75 30C75 30 65 40 65 50C65 60 75 70 75 70" 
      stroke="#ccfbf1" 
      strokeWidth="6" 
      strokeLinecap="round" 
      opacity="0.9"
    />
  </svg>
);

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    identifier: '', // Used for login (email or phone)
    email: '',      // Used for register
    phone: '',      // Used for register
    name: '',
    password: ''
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Fix: Made handleSubmit async to correctly await AuthService results
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isLogin) {
        if (!formData.identifier || !formData.password) {
           setError("Please enter your email/phone and password.");
           setLoading(false);
           return;
        }
        // Fix: Awaiting the login call to avoid Promise errors
        const result = await AuthService.login(formData.identifier, formData.password);
        if (result.success && result.user) {
          onLoginSuccess(result.user);
        } else {
          setError(result.message || 'Login failed');
          setFormData(prev => ({ ...prev, password: '' }));
          setLoading(false);
        }
      } else {
        // Register Validation
        if (!formData.email || !formData.phone || !formData.name || !formData.password) {
          setError("All fields are required.");
          setLoading(false);
          return;
        }
        
        // Fix: Awaiting the register call to avoid Promise errors
        const result = await AuthService.register(formData.email, formData.phone, formData.name, formData.password);
        if (result.success && result.user) {
          onLoginSuccess(result.user);
        } else {
          setError(result.message || 'Registration failed');
          setLoading(false);
        }
      }
    } catch (err) {
      setError("An error occurred during authentication.");
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setError(null);
    setFormData({ identifier: '', email: '', phone: '', name: '', password: '' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="mb-8 text-center animate-fade-in-up">
        <div className="flex justify-center mb-6">
          <DocSlimLogoLarge className="w-20 h-20 shadow-xl shadow-medical-200" />
        </div>
        <h1 className="text-4xl font-bold text-slate-900 tracking-tighter uppercase">DocSlim</h1>
        <p className="text-medical-600 font-medium mt-2 tracking-wide text-sm uppercase">Smart Clinical Weight Management</p>
      </div>

      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 w-full max-w-md overflow-hidden animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
        <div className="p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
            {isLogin ? <LogIn className="w-5 h-5 text-medical-600" /> : <UserPlus className="w-5 h-5 text-medical-600" />}
            {isLogin ? 'Sign in to your account' : 'Create a new profile'}
          </h2>

          {error && (
            <div className="mb-4 bg-red-50 text-red-600 p-3 rounded-lg text-sm flex items-center gap-2 border border-red-100 animate-pulse">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Login Mode Fields */}
            {isLogin && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email or Phone Number</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <UserIcon className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    required
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors"
                    placeholder="name@example.com or 050..."
                    value={formData.identifier}
                    onChange={e => setFormData({ ...formData, identifier: e.target.value })}
                  />
                </div>
              </div>
            )}

            {/* Register Mode Fields */}
            {!isLogin && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
                  <input
                    type="text"
                    required
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors"
                    placeholder="e.g. Dr. John Smith"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-4 w-4 text-gray-400" />
                    </div>
                    <input
                      type="email"
                      required
                      className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors"
                      placeholder="doctor@clinic.com"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-4 w-4 text-gray-400" />
                    </div>
                    <input
                      type="tel"
                      required
                      className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors"
                      placeholder="+971..."
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="password"
                  required
                  className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={e => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-medical-600 text-white py-2.5 rounded-lg font-medium hover:bg-medical-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-medical-500 disabled:opacity-70 disabled:cursor-wait transition-all shadow-sm flex items-center justify-center gap-2 mt-6"
            >
              {loading ? (
                <span>Processing...</span>
              ) : (
                <>
                  {isLogin ? 'Sign In' : 'Create Account'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
        <div className="bg-gray-50 p-4 border-t border-gray-100 text-center">
          <button
            onClick={toggleMode}
            className="text-sm text-medical-700 font-medium hover:text-medical-800 transition-colors focus:outline-none"
          >
            {isLogin ? "New here? Create a profile" : "Already have an account? Sign in"}
          </button>
        </div>
      </div>
      <p className="mt-8 text-xs text-slate-400 max-w-xs text-center">
        DocSlim System • Data stored locally
      </p>
    </div>
  );
};