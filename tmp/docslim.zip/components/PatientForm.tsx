
import React, { useEffect, useState } from 'react';
import { Patient, Gender, ActivityLevel, MedicationType, MOUNJARO_DOSES, WEGOVY_DOSES, OZEMPIC_DOSES, RYBELSUS_DOSES } from '../types';
import { Calculator, ArrowRight, ClipboardList, ArrowLeft, Flame, Utensils, TrendingDown, History, Info } from 'lucide-react';

interface PatientFormProps {
  currentPatient: Patient;
  onChange: (patient: Patient) => void;
  onNext: () => void;
  onBack: () => void;
  loading: boolean;
}

const ACTIVITY_MULTIPLIERS: Record<ActivityLevel, number> = {
  [ActivityLevel.Sedentary]: 1.2,
  [ActivityLevel.LightlyActive]: 1.375,
  [ActivityLevel.ModeratelyActive]: 1.55,
  [ActivityLevel.VeryActive]: 1.725
};

const ACTIVITY_DESCRIPTIONS: Record<ActivityLevel, string> = {
  [ActivityLevel.Sedentary]: 'Little or no exercise, desk job',
  [ActivityLevel.LightlyActive]: 'Light exercise or sports 1-3 days/week',
  [ActivityLevel.ModeratelyActive]: 'Moderate exercise or sports 3-5 days/week',
  [ActivityLevel.VeryActive]: 'Hard exercise or sports 6-7 days/week'
};

export const PatientForm: React.FC<PatientFormProps> = ({ 
  currentPatient, 
  onChange, 
  onNext, 
  onBack,
  loading 
}) => {
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft'>('cm');
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lbs'>('kg');

  // Auto-calculate BMI, BMR, Daily Calories, and Weight Loss Target
  useEffect(() => {
    let updates: Partial<Patient> = {};
    let hasUpdates = false;

    if (currentPatient.height && currentPatient.weight) {
      const hM = Number(currentPatient.height) / 100;
      const wKg = Number(currentPatient.weight);
      if (hM > 0) {
        const bmi = wKg / (hM * hM);
        if (bmi !== currentPatient.bmi) {
          updates.bmi = bmi;
          hasUpdates = true;
        }
      }
    } else if (currentPatient.bmi !== null) {
      updates.bmi = null;
      hasUpdates = true;
    }

    if (currentPatient.weight && currentPatient.height && currentPatient.age && currentPatient.gender) {
      const w = Number(currentPatient.weight);
      const h = Number(currentPatient.height);
      const a = Number(currentPatient.age);
      
      let bmr = 0;
      if (currentPatient.gender === Gender.Male) {
        bmr = (10 * w) + (6.25 * h) - (5 * a) + 5;
      } else {
        bmr = (10 * w) + (6.25 * h) - (5 * a) - 161;
      }

      const multiplier = ACTIVITY_MULTIPLIERS[currentPatient.activityLevel] || 1.2;
      const dailyCalories = bmr * multiplier;
      const weightLossCalories = Math.max(1200, dailyCalories - 500);

      if (Math.round(bmr) !== Math.round(currentPatient.bmr || 0)) {
        updates.bmr = bmr;
        hasUpdates = true;
      }
      if (Math.round(dailyCalories) !== Math.round(currentPatient.dailyCalories || 0)) {
        updates.dailyCalories = dailyCalories;
        hasUpdates = true;
      }
      if (Math.round(weightLossCalories) !== Math.round(currentPatient.weightLossCalories || 0)) {
        updates.weightLossCalories = weightLossCalories;
        hasUpdates = true;
      }
    }

    if (hasUpdates) {
      onChange({ ...currentPatient, ...updates });
    }
  }, [
    currentPatient.height, 
    currentPatient.weight, 
    currentPatient.age, 
    currentPatient.gender, 
    currentPatient.activityLevel
  ]);

  const handleInputChange = (field: keyof Patient, value: any) => {
    onChange({ ...currentPatient, [field]: value });
  };

  const getBMIColor = (bmi: number | null) => {
    if (!bmi) return 'bg-gray-100 text-gray-500';
    if (bmi < 18.5) return 'bg-blue-100 text-blue-800';
    if (bmi < 25) return 'bg-green-100 text-green-800';
    if (bmi < 30) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const getBMILabel = (bmi: number | null) => {
    if (!bmi) return 'Waiting for data...';
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal weight';
    if (bmi < 30) return 'Overweight';
    if (bmi < 35) return 'Obesity Class I';
    if (bmi < 40) return 'Obesity Class II';
    return 'Obesity Class III';
  };
  
  const getDisplayHeight = () => {
    if (!currentPatient.height) return '';
    if (heightUnit === 'cm') return `${currentPatient.height}`;
    const totalInches = Number(currentPatient.height) / 2.54;
    const ft = Math.floor(totalInches / 12);
    const inch = Math.round(totalInches % 12);
    return `${ft}' ${inch}"`;
  };

  const getDisplayWeight = () => {
    if (!currentPatient.weight) return '';
    if (weightUnit === 'kg') return `${currentPatient.weight}`;
    return (Number(currentPatient.weight) * 2.20462).toFixed(1);
  };
  
  const isFormValid = currentPatient.height && currentPatient.weight;

  const getDoseOptions = (med: MedicationType) => {
    switch (med) {
      case 'Mounjaro': return MOUNJARO_DOSES;
      case 'Wegovy': return WEGOVY_DOSES;
      case 'Ozempic': return OZEMPIC_DOSES;
      case 'Rybelsus': return RYBELSUS_DOSES;
      default: return [];
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full">
      <div className="p-5 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="flex items-center opacity-50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-medical-100 text-medical-600 font-bold text-sm">✓</div>
            <div className="ml-3 hidden sm:block">
               <h2 className="text-sm font-semibold text-gray-900">Identity</h2>
            </div>
          </div>
          <div className="h-px w-8 bg-gray-300 mx-2"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-medical-600 text-white font-bold text-sm">2</div>
            <div className="ml-3">
              <h2 className="text-sm font-semibold text-gray-900">Clinical</h2>
              <p className="text-xs text-gray-500">Analysis & History</p>
            </div>
          </div>
          <div className="h-px w-8 bg-gray-300 mx-2"></div>
          <div className="flex items-center opacity-50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 text-gray-500 font-bold text-sm">3</div>
          </div>
        </div>
      </div>
      
      <div className="p-6 overflow-y-auto flex-1">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2 border-b border-gray-100 pb-2">
                 <Calculator className="w-5 h-5 text-gray-400" />
                 <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider">Vitals & Activity</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                   <div className="flex justify-between items-center mb-1">
                      <label className="block text-sm font-medium text-gray-700">Height</label>
                      <button 
                        onClick={() => setHeightUnit(prev => prev === 'cm' ? 'ft' : 'cm')}
                        className="text-[10px] bg-gray-100 px-1.5 py-0.5 rounded text-gray-500 hover:text-medical-600 font-medium"
                      >
                        {heightUnit.toUpperCase()}
                      </button>
                   </div>
                  <input 
                    type="text"
                    disabled
                    className="mt-1 block w-full rounded-md border-gray-200 bg-gray-50 text-gray-600 cursor-not-allowed shadow-sm sm:text-sm p-2.5 border"
                    value={getDisplayHeight()}
                  />
                </div>
                <div>
                   <div className="flex justify-between items-center mb-1">
                      <label className="block text-sm font-medium text-gray-700">Weight</label>
                      <button 
                        onClick={() => setWeightUnit(prev => prev === 'kg' ? 'lbs' : 'kg')}
                        className="text-[10px] bg-gray-100 px-1.5 py-0.5 rounded text-gray-500 hover:text-medical-600 font-medium"
                      >
                        {weightUnit.toUpperCase()}
                      </button>
                   </div>
                  <input 
                    type="text"
                    disabled
                    className="mt-1 block w-full rounded-md border-gray-200 bg-gray-50 text-gray-600 cursor-not-allowed shadow-sm sm:text-sm p-2.5 border"
                    value={getDisplayWeight()}
                  />
                </div>
              </div>

              <div className={`p-3 rounded-md flex justify-between items-center ${getBMIColor(currentPatient.bmi)} border border-opacity-20`}>
                <span className="font-semibold text-sm">BMI: {currentPatient.bmi ? currentPatient.bmi.toFixed(1) : '--'}</span>
                <span className="text-xs font-bold uppercase tracking-wide">{getBMILabel(currentPatient.bmi)}</span>
              </div>
              
              <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Activity Level</label>
                  <select 
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-all"
                    value={currentPatient.activityLevel}
                    onChange={(e) => handleInputChange('activityLevel', e.target.value as ActivityLevel)}
                  >
                    {Object.values(ActivityLevel).map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                  <div className="bg-medical-50/50 p-2.5 rounded-lg border border-medical-100/50 flex items-start gap-2">
                    <Info className="w-3.5 h-3.5 text-medical-600 mt-0.5 shrink-0" />
                    <p className="text-[11px] text-medical-800 font-medium leading-tight italic">
                      {ACTIVITY_DESCRIPTIONS[currentPatient.activityLevel]}
                    </p>
                  </div>
               </div>

               <div className="bg-orange-50 p-4 rounded-lg border border-orange-100 space-y-3">
                  <h3 className="text-xs font-bold text-orange-600 uppercase tracking-wider flex items-center gap-1">
                    <Flame className="w-3 h-3" /> Metabolic Stats
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">BMR (Resting)</p>
                      <p className="text-lg font-bold text-gray-800">
                        {currentPatient.bmr ? Math.round(currentPatient.bmr) : '--'} <span className="text-xs font-normal text-gray-500">kcal</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Utensils className="w-3 h-3"/> Maintenance</p>
                      <p className="text-lg font-bold text-gray-800">
                        {currentPatient.dailyCalories ? Math.round(currentPatient.dailyCalories) : '--'} <span className="text-xs font-normal text-gray-500">kcal</span>
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 pt-2 border-t border-orange-100">
                    <p className="text-xs text-orange-700 mb-1 flex items-center gap-1 font-semibold">
                      <TrendingDown className="w-3 h-3" /> Weight Loss Target
                    </p>
                    <div className="flex items-baseline gap-2">
                       <p className="text-xl font-extrabold text-orange-600">
                          {currentPatient.weightLossCalories ? Math.round(currentPatient.weightLossCalories) : '--'}
                       </p>
                       <span className="text-xs text-orange-600">kcal/day</span>
                    </div>
                  </div>
               </div>
            </div>

            {currentPatient.gender === Gender.Female && (
              <div className="bg-pink-50 p-4 rounded-lg border border-pink-100">
                <h3 className="text-xs font-bold text-pink-500 uppercase tracking-wider mb-3">Pregnancy Screening</h3>
                <div className="flex gap-4">
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox"
                      className="rounded text-pink-500 focus:ring-pink-500"
                      checked={currentPatient.isPregnant}
                      onChange={(e) => handleInputChange('isPregnant', e.target.checked)}
                    />
                    <span className="text-sm text-gray-700">Is Pregnant?</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox"
                      className="rounded text-pink-500 focus:ring-pink-500"
                      checked={currentPatient.isBreastfeeding}
                      onChange={(e) => handleInputChange('isBreastfeeding', e.target.checked)}
                    />
                    <span className="text-sm text-gray-700">Is Breastfeeding?</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
             <div className="space-y-4">
               <div className="flex items-center gap-2 mb-2 border-b border-gray-100 pb-2">
                 <ClipboardList className="w-5 h-5 text-gray-400" />
                 <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider">Medical History</h3>
               </div>
               
               <div>
                 <label className="block text-sm font-medium text-gray-700">Chronic Illnesses</label>
                 <textarea 
                   rows={3}
                   className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border"
                   placeholder="e.g. Hypertension, Type 2 Diabetes..."
                   value={currentPatient.chronicIllnesses}
                   onChange={(e) => handleInputChange('chronicIllnesses', e.target.value)}
                 />
               </div>

               <div>
                 <label className="block text-sm font-medium text-gray-700">Current Medications</label>
                 <textarea 
                   rows={3}
                   className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border"
                   placeholder="e.g. Metformin 500mg..."
                   value={currentPatient.medications}
                   onChange={(e) => handleInputChange('medications', e.target.value)}
                 />
               </div>

               <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 space-y-4">
                  <div className="flex items-center space-x-2">
                    <input 
                      type="checkbox"
                      className="rounded text-medical-600 focus:ring-medical-500 h-4 w-4"
                      id="prev-glp1"
                      checked={currentPatient.previousGlp1Use || false}
                      onChange={(e) => handleInputChange('previousGlp1Use', e.target.checked)}
                    />
                    <label htmlFor="prev-glp1" className="text-sm text-gray-700 font-bold flex items-center gap-2">
                       <History className="w-4 h-4 text-medical-600" />
                       Previous History of GLP-1 Use
                    </label>
                  </div>
                  
                  {currentPatient.previousGlp1Use && (
                    <div className="ml-6 space-y-3 animate-fade-in-up">
                       <div className="grid grid-cols-2 gap-3">
                         <div>
                           <label className="block text-[10px] font-bold text-gray-500 uppercase">Medication (Optional)</label>
                           <select 
                             className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 text-xs p-2 border"
                             value={currentPatient.previousMedication || ''}
                             onChange={(e) => handleInputChange('previousMedication', e.target.value as MedicationType)}
                           >
                             <option value="">Select...</option>
                             <option value="Mounjaro">Mounjaro</option>
                             <option value="Wegovy">Wegovy</option>
                             <option value="Ozempic">Ozempic</option>
                             <option value="Rybelsus">Rybelsus</option>
                             <option value="Other">Other</option>
                           </select>
                         </div>
                         <div>
                           <label className="block text-[10px] font-bold text-gray-500 uppercase">Last Dose (Optional)</label>
                           {['Mounjaro', 'Wegovy', 'Ozempic', 'Rybelsus'].includes(currentPatient.previousMedication || '') ? (
                             <select 
                               className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 text-xs p-2 border"
                               value={currentPatient.previousDose || ''}
                               onChange={(e) => handleInputChange('previousDose', e.target.value)}
                             >
                               <option value="">Select Dose...</option>
                               {getDoseOptions(currentPatient.previousMedication as MedicationType).map(d => (
                                 <option key={d} value={d}>{d}</option>
                               ))}
                             </select>
                           ) : (
                             <input 
                               type="text"
                               placeholder="e.g. 10mg"
                               className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 text-xs p-2 border"
                               value={currentPatient.previousDose || ''}
                               onChange={(e) => handleInputChange('previousDose', e.target.value)}
                             />
                           )}
                         </div>
                       </div>
                    </div>
                  )}
               </div>
             </div>
          </div>
        </div>
      </div>

      <div className="p-5 border-t border-gray-100 bg-gray-50 flex justify-between items-center">
         <button onClick={onBack} className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2">
           <ArrowLeft className="w-4 h-4" /> Back to Identity
         </button>
         <button onClick={onNext} disabled={!isFormValid || loading} className="bg-medical-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-medical-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-medical-500 disabled:opacity-50 transition-all shadow-sm flex items-center gap-2">
           {loading ? 'Analyzing...' : 'Next: Treatment Plan'}
           {!loading && <ArrowRight className="w-4 h-4" />}
         </button>
      </div>
    </div>
  );
};
