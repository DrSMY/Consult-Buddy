
import React from 'react';
import { UserPlus, History, ArrowRight, ClipboardCheck } from 'lucide-react';

interface SelectionPageProps {
  onNewPatient: () => void;
  onFollowup: () => void;
}

export const SelectionPage: React.FC<SelectionPageProps> = ({ onNewPatient, onFollowup }) => {
  return (
    <div className="h-full flex flex-col items-center justify-center p-4 animate-fade-in">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Welcome to DocSlim</h2>
        <p className="text-slate-500 mt-2 font-medium">Please select the encounter type to proceed.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
        {/* New Patient Option */}
        <div 
          onClick={onNewPatient}
          className="group relative bg-white rounded-[2.5rem] p-8 border-2 border-slate-100 hover:border-medical-500 hover:shadow-2xl hover:shadow-medical-500/10 transition-all cursor-pointer overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <UserPlus className="w-32 h-32" />
          </div>
          
          <div className="w-16 h-16 bg-medical-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-medical-500 group-hover:text-white transition-all">
            <UserPlus className="w-8 h-8" />
          </div>
          
          <h3 className="text-2xl font-bold text-slate-900 mb-3">New Patient</h3>
          <p className="text-slate-500 text-sm leading-relaxed mb-8">
            Start a fresh intake process for a new patient including demographics, full medical history, and clinical analysis.
          </p>
          
          <div className="flex items-center gap-2 text-medical-600 font-bold text-sm uppercase tracking-wider">
            Start New Intake
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>

        {/* Follow-up Option */}
        <div 
          onClick={onFollowup}
          className="group relative bg-white rounded-[2.5rem] p-8 border-2 border-slate-100 hover:border-indigo-500 hover:shadow-2xl hover:shadow-indigo-500/10 transition-all cursor-pointer overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <History className="w-32 h-32" />
          </div>
          
          <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-500 group-hover:text-white transition-all">
            <History className="w-8 h-8" />
          </div>
          
          <h3 className="text-2xl font-bold text-slate-900 mb-3">Patient Follow-up</h3>
          <p className="text-slate-500 text-sm leading-relaxed mb-8">
            Review progress, record weight changes, manage side effects, and adjust GLP-1 dosages for existing patients.
          </p>
          
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm uppercase tracking-wider">
            Start Follow-up
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </div>
      
      <div className="mt-12 flex items-center gap-2 text-slate-400 font-medium text-xs py-2 px-4 bg-white rounded-full border border-slate-100 shadow-sm">
        <ClipboardCheck className="w-3.5 h-3.5" />
        All data is synced to your clinical cloud storage.
      </div>
    </div>
  );
};
