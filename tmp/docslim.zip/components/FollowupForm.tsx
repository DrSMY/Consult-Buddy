import React, { useState, useMemo } from 'react';
import { Patient, Gender, FollowupData } from '../types';
import { History, ArrowRight, ArrowLeft, RefreshCw, Wand2, SearchCheck, UserPlus, Search, X, CheckCircle2, Calendar, Pill, Weight as WeightIcon } from 'lucide-react';
import { parsePatientNotes } from '../services/gemini';

interface FollowupFormProps {
  currentPatient: Patient;
  onChange: (patient: Patient) => void;
  patients: Patient[];
  onNext: () => void;
  onBack: () => void;
}

export const FollowupForm: React.FC<FollowupFormProps> = ({ 
  currentPatient, 
  onChange, 
  patients,
  onNext, 
  onBack 
}) => {
  const [smartInput, setSmartInput] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [patientSearch, setPatientSearch] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [selectionMode, setSelectionMode] = useState<'search' | 'manual' | null>(null);
  const [linkedPatient, setLinkedPatient] = useState<Patient | null>(null);

  const filteredExistingPatients = useMemo(() => {
    if (!patientSearch.trim()) return [];
    const term = patientSearch.toLowerCase();
    return patients.filter(p => 
      p.name.toLowerCase().includes(term) || 
      p.mobileNumber.includes(term) || 
      p.bookingId?.toLowerCase().includes(term)
    ).slice(0, 5);
  }, [patientSearch, patients]);

  const followupData: FollowupData = currentPatient.followupData || {
    previousDose: '',
    nextDose: '',
    sideEffects: '',
    weightLost: '',
    notes: ''
  };

  const handleInputChange = (field: keyof Patient, value: any) => {
    onChange({ ...currentPatient, [field]: value });
  };

  const handleFollowupChange = (field: keyof FollowupData, value: any) => {
    onChange({
      ...currentPatient,
      followupData: { ...followupData, [field]: value }
    });
  };

  const selectExistingPatient = (p: Patient) => {
    setLinkedPatient(p);
    onChange({
      ...currentPatient,
      name: p.name,
      mobileNumber: p.mobileNumber,
      bookingId: p.bookingId,
      age: p.age,
      gender: p.gender,
      height: p.height,
      // Clear weight so doctor enters the NEW weight for this followup
      weight: '',
      bmi: null, 
      chronicIllnesses: p.chronicIllnesses,
      medications: p.medications,
      previousGlp1Use: true,
      previousMedication: p.treatment?.medication,
      previousDose: p.treatment?.dose,
      followupData: {
        ...followupData,
        previousDose: p.treatment?.dose || ''
      }
    });
    setPatientSearch('');
    setShowSearchResults(false);
    setSelectionMode('manual'); // Transition to form entry with linked data
  };

  const handleSmartFill = async () => {
    if (!smartInput.trim()) return;
    setIsParsing(true);
    const extractedData = await parsePatientNotes(smartInput);
    const updated = { ...currentPatient };
    if (extractedData.name) updated.name = extractedData.name;
    if (extractedData.mobileNumber) updated.mobileNumber = extractedData.mobileNumber;
    if (extractedData.bookingId) updated.bookingId = extractedData.bookingId;
    if (extractedData.age) updated.age = extractedData.age;
    if (extractedData.weight) updated.weight = extractedData.weight;
    updated.notes = (updated.notes ? updated.notes + '\n\n' : '') + `[Follow-up Raw]: ${smartInput}`;
    onChange(updated);
    setIsParsing(false);
    setSmartInput('');
  };

  const isFormValid = currentPatient.name && currentPatient.bookingId && currentPatient.weight !== '';

  return (
    <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-200 overflow-hidden flex flex-col h-full animate-slide-up">
      <div className="px-8 py-6 border-b border-slate-100 bg-indigo-50/30 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-white rounded-xl transition-colors shadow-sm">
            <ArrowLeft className="w-5 h-5 text-indigo-600" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Follow-up Encounter</h2>
            <p className="text-xs font-semibold text-indigo-600 uppercase tracking-widest mt-0.5">Link History & Progress</p>
          </div>
        </div>
      </div>

      <div className="p-8 overflow-y-auto flex-1 custom-scrollbar">
        <div className="max-w-2xl mx-auto space-y-8">
          
          {!selectionMode && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 animate-fade-in py-10">
              <button 
                onClick={() => setSelectionMode('search')}
                className="group flex flex-col items-center justify-center p-10 border-2 border-dashed border-slate-200 rounded-[2.5rem] hover:border-indigo-500 hover:bg-indigo-50/50 transition-all gap-4"
              >
                <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                   <SearchCheck className="w-8 h-8 text-indigo-600" />
                </div>
                <div className="text-center">
                  <span className="block font-bold text-slate-900 text-lg">Search Existing Patient</span>
                  <span className="text-sm text-slate-500">Link to clinical history & previous meds</span>
                </div>
              </button>
              
              <button 
                onClick={() => setSelectionMode('manual')}
                className="group flex flex-col items-center justify-center p-10 border-2 border-dashed border-slate-200 rounded-[2.5rem] hover:border-medical-500 hover:bg-medical-50/50 transition-all gap-4"
              >
                <div className="w-16 h-16 bg-medical-100 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                   <UserPlus className="w-8 h-8 text-medical-600" />
                </div>
                <div className="text-center">
                  <span className="block font-bold text-slate-900 text-lg">New Follow-up Entry</span>
                  <span className="text-sm text-slate-500">Manual entry for first-time follow-up</span>
                </div>
              </button>
            </div>
          )}

          {selectionMode === 'search' && !linkedPatient && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Find Patient Record</h3>
                <button onClick={() => setSelectionMode(null)} className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1">
                  <X className="w-3 h-3" /> Cancel
                </button>
              </div>

              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="text" 
                  autoFocus
                  placeholder="Search by Name, Phone, or Booking ID..."
                  className="w-full rounded-2xl border-slate-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 text-base p-5 pl-12 bg-white transition-all outline-none border shadow-sm"
                  value={patientSearch}
                  onChange={(e) => {
                    setPatientSearch(e.target.value);
                    setShowSearchResults(true);
                  }}
                />
                
                {showSearchResults && patientSearch.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-3 bg-white border border-slate-200 rounded-[2rem] shadow-2xl z-50 overflow-hidden animate-fade-in border-t-0">
                    {filteredExistingPatients.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 italic">No matches found for "{patientSearch}"</div>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {filteredExistingPatients.map(p => (
                          <div key={p.id} onClick={() => selectExistingPatient(p)} className="p-5 hover:bg-indigo-50 cursor-pointer transition-colors flex items-center justify-between group">
                            <div className="flex items-center gap-4">
                               <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 font-bold group-hover:bg-indigo-200 group-hover:text-indigo-700 transition-colors">
                                 {p.name.charAt(0)}
                               </div>
                               <div>
                                 <p className="font-bold text-slate-900">{p.name}</p>
                                 <p className="text-xs text-slate-500 flex items-center gap-2">
                                   {p.mobileNumber} • ID: {p.bookingId}
                                 </p>
                               </div>
                            </div>
                            <div className="text-right">
                               <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Last Encounter</p>
                               <p className="text-xs font-bold text-slate-700">{new Date(p.dateAdded).toLocaleDateString()}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {selectionMode === 'manual' && (
            <div className="space-y-8 animate-fade-in">
              
              {linkedPatient && (
                <div className="bg-emerald-50 border border-emerald-100 rounded-3xl p-6 flex items-start gap-4 animate-slide-up">
                   <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                   </div>
                   <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-emerald-900 text-lg leading-tight">History Linked: {linkedPatient.name}</h4>
                        <button onClick={() => { setLinkedPatient(null); handleInputChange('name', ''); handleInputChange('bookingId', ''); }} className="text-xs font-bold text-emerald-700 hover:underline">Unlink Record</button>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-3">
                         <div className="flex items-center gap-2 text-xs font-medium text-emerald-700">
                            <Calendar className="w-3.5 h-3.5" /> Last Visit: {new Date(linkedPatient.dateAdded).toLocaleDateString()}
                         </div>
                         <div className="flex items-center gap-2 text-xs font-medium text-emerald-700">
                            <Pill className="w-3.5 h-3.5" /> Last Med: {linkedPatient.treatment?.medication || 'None'}
                         </div>
                      </div>
                   </div>
                </div>
              )}

              <div className="bg-white p-6 rounded-[2rem] border border-indigo-100 shadow-sm space-y-4">
                <label className="block text-sm font-bold text-indigo-800 flex items-center gap-2">
                  <Wand2 className="w-4 h-4 text-indigo-600" /> Smart Fill Follow-up
                </label>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input 
                    type="text" 
                    placeholder="E.g. Patient lost 3kg, occasional nausea, wants to increase dose..."
                    className="flex-1 rounded-xl border-slate-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 text-sm p-4 bg-slate-50/50 outline-none border transition-all"
                    value={smartInput}
                    onChange={(e) => setSmartInput(e.target.value)}
                  />
                  <button onClick={handleSmartFill} disabled={isParsing} className="bg-indigo-600 text-white rounded-xl text-sm font-bold px-6 py-4 flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 active:scale-95 transition-all">
                    {isParsing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                    Fill
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="sm:col-span-2 space-y-2">
                  <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider text-[11px]">Patient Name <span className="text-red-500">*</span></label>
                  <input type="text" className="w-full rounded-2xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-4 border outline-none font-medium" value={currentPatient.name} onChange={(e) => handleInputChange('name', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider text-[11px]">Booking Reference <span className="text-red-500">*</span></label>
                  <input type="text" className="w-full rounded-2xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-4 border outline-none font-medium" value={currentPatient.bookingId} onChange={(e) => handleInputChange('bookingId', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-bold text-medical-700 uppercase tracking-wider text-[11px] flex items-center gap-2">
                    <WeightIcon className="w-3.5 h-3.5" /> NEW Weight (KG) <span className="text-red-500">*</span>
                  </label>
                  <input type="number" step="0.1" autoFocus={!!linkedPatient} className="w-full rounded-2xl border-medical-200 bg-medical-50/30 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-4 border outline-none font-bold text-medical-900" placeholder="e.g. 74.5" value={currentPatient.weight} onChange={(e) => handleInputChange('weight', e.target.value === '' ? '' : Number(e.target.value))} />
                </div>
              </div>

              <div className="pt-8 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider text-[11px]">Previous Dose (Auto-linked)</label>
                  <input type="text" className="w-full rounded-2xl border-slate-100 bg-slate-50/50 text-slate-500 text-sm p-4 border cursor-not-allowed" readOnly value={followupData.previousDose} />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider text-[11px]">Next Planned Dose</label>
                  <input type="text" className="w-full rounded-2xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-4 border outline-none" placeholder="e.g. 5 mg" value={followupData.nextDose} onChange={(e) => handleFollowupChange('nextDose', e.target.value)} />
                </div>
                <div className="sm:col-span-2 space-y-2">
                  <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider text-[11px]">Side Effects Observed</label>
                  <textarea rows={2} className="w-full rounded-2xl border-slate-200 focus:border-medical-500 focus:ring-4 focus:ring-medical-500/10 text-sm p-4 border outline-none" placeholder="e.g. Mild nausea first 2 days, resolved with hydration" value={followupData.sideEffects} onChange={(e) => handleFollowupChange('sideEffects', e.target.value)} />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="px-8 py-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
        <button 
          onClick={onNext}
          disabled={!isFormValid}
          className="bg-medical-600 text-white px-12 py-4 rounded-2xl font-bold hover:bg-medical-700 disabled:opacity-50 transition-all flex items-center gap-3 shadow-xl shadow-medical-600/20 active:scale-95"
        >
          Proceed with Follow-up
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};