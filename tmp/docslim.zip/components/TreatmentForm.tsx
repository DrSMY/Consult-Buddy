
import React, { useEffect, useState } from 'react';
import { Patient, TreatmentPlan, MOUNJARO_DOSES, WEGOVY_DOSES, OZEMPIC_DOSES, RYBELSUS_DOSES, MedicationType, Gender, User } from '../types';
import { ArrowLeft, Check, Pill, StickyNote, FileText, Sparkles, BookOpen, Loader2, FlaskConical } from 'lucide-react';
import { generatePatientGuide } from '../services/gemini';

interface TreatmentFormProps {
  currentPatient: Patient;
  onUpdateTreatment: (treatment: TreatmentPlan) => void;
  onBack: () => void;
  onComplete: () => void;
  currentUser: User;
}

export const TreatmentForm: React.FC<TreatmentFormProps> = ({ 
  currentPatient, 
  onUpdateTreatment, 
  onBack,
  onComplete,
  currentUser
}) => {
  const [isGeneratingGuide, setIsGeneratingGuide] = useState(false);

  // Initialize with the requested default note if none exists
  const treatment = currentPatient.treatment || {
    medication: '',
    datePrescribed: new Date().toISOString(),
    notes: 'He needs monthly followup and weight loss program blood test.',
    bloodTestRequired: false
  } as TreatmentPlan;

  const handleFieldChange = (field: keyof TreatmentPlan, value: any) => {
    onUpdateTreatment({
      ...treatment,
      [field]: value
    });
  };

  const getBmiCategory = (bmi: number) => {
    if (bmi < 25) return 'normal weight';
    if (bmi < 30) return 'overweight';
    if (bmi < 35) return 'Obesity Class I';
    if (bmi < 40) return 'Obesity Class II';
    return 'Obesity Class III';
  };

  const generateDoctorSuggestion = () => {
    if (!treatment.medication || !currentPatient.name) return;

    const medName = treatment.medication === 'Other' 
      ? (treatment.otherDetail || 'Medication') 
      : treatment.medication;
    
    const doseText = treatment.dose ? ` ${treatment.dose}` : '';
    let pronoun = 'the patient';
    let salutation = 'Mr';
    
    if (currentPatient.gender === Gender.Male) {
      pronoun = 'He';
      salutation = 'Mr';
    } else if (currentPatient.gender === Gender.Female) {
      pronoun = 'She';
      salutation = 'Ms';
    }

    const bmiVal = currentPatient.bmi || 0;
    const bmiCat = getBmiCategory(bmiVal);
    
    let historyText = 'with no previous history of use of GLP1 meds';
    if (currentPatient.previousGlp1Use) {
      const prevMed = currentPatient.previousMedication ? ` of ${currentPatient.previousMedication}` : '';
      const prevDose = currentPatient.previousDose ? ` at ${currentPatient.previousDose}` : '';
      historyText = `with previous history of use of GLP1 meds${prevMed}${prevDose}`;
    }
      
    const conditions = currentPatient.chronicIllnesses 
      ? `, with ${currentPatient.chronicIllnesses}` 
      : ', with no known chronic illnesses';

    const weight = typeof currentPatient.weight === 'number' ? currentPatient.weight : 0;
    const proteinMin = Math.round(weight * 1.2);
    const proteinMax = Math.round(weight * 1.5);
    const weightLossCals = currentPatient.weightLossCalories ? Math.round(currentPatient.weightLossCalories) : '---';

    const bloodTestSuffix = treatment.bloodTestRequired 
      ? "\n- Weight Loss Blood Test required: https://www.dardoc.com/dubai/lab-test/weight-loss-blood-test"
      : "";

    // Added phone number to the identity line
    const text = `booking ID ${currentPatient.bookingId || 'N/A'} , ${salutation} ${currentPatient.name} (${currentPatient.mobileNumber || 'No phone'}) \nprescribed ${medName}${doseText} \n${pronoun} is ${bmiCat} ${historyText}${conditions}, ${pronoun.toLowerCase()} has no contraindications to GLP 1, ${pronoun.toLowerCase()} is advised to take ${proteinMin} grams to ${proteinMax} grams of protein, with Weight Loss Target ${weightLossCals} kcal/day. ${treatment.notes || ''}${bloodTestSuffix}`;

    handleFieldChange('doctorSuggestions', text.trim());
  };

  const handleGenerateFullGuide = async () => {
    if (!treatment.medication) return;
    setIsGeneratingGuide(true);
    const patientSnapshot = { ...currentPatient, treatment };
    const guideText = await generatePatientGuide(patientSnapshot);
    
    handleFieldChange('patientGuide', guideText);
    setIsGeneratingGuide(false);
  };

  useEffect(() => {
    if (treatment.medication) {
       generateDoctorSuggestion();
    }
  }, [treatment.medication, treatment.dose, treatment.otherDetail, treatment.notes, treatment.bloodTestRequired, currentPatient.mobileNumber]);

  const isComplete = treatment.medication !== '' && 
    (treatment.medication === 'Other' ? !!treatment.otherDetail : !!treatment.dose);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full">
      <div className="p-5 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="flex items-center opacity-50">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-medical-100 text-medical-600 font-bold text-sm">✓</div>
            <div className="ml-3 hidden sm:block">
              <h2 className="text-sm font-semibold text-gray-900">Patient Intake</h2>
              <p className="text-xs text-gray-500">Demographics & History</p>
            </div>
          </div>
          <div className="h-px w-8 bg-gray-300 mx-2"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-medical-600 text-white font-bold text-sm">2</div>
            <div className="ml-3">
              <h2 className="text-sm font-semibold text-gray-900">Treatment</h2>
              <p className="text-xs text-gray-500">Plan & Medication</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 overflow-y-auto flex-1 custom-scrollbar">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-start gap-3">
            <Pill className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="text-sm font-semibold text-blue-900">Select Medication</h3>
              <p className="text-xs text-blue-700 mt-1">Choose the prescribed GLP-1 agonist or alternative treatment.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
            {['Mounjaro', 'Wegovy', 'Ozempic', 'Rybelsus', 'Other'].map((med) => (
              <div 
                key={med}
                onClick={() => handleFieldChange('medication', med as MedicationType)}
                className={`
                  cursor-pointer rounded-lg border-2 p-3 flex flex-col items-center justify-center gap-2 transition-all
                  ${treatment.medication === med 
                    ? 'border-medical-500 bg-medical-50 text-medical-700 shadow-sm' 
                    : 'border-gray-200 hover:border-gray-300 text-gray-600 hover:bg-gray-50'
                  }
                `}
              >
                <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${treatment.medication === med ? 'border-medical-600 bg-medical-600' : 'border-gray-400'}`}>
                  {treatment.medication === med && <Check className="w-2 h-2 text-white" />}
                </div>
                <span className="text-xs font-bold">{med}</span>
              </div>
            ))}
          </div>

          {treatment.medication && treatment.medication !== 'Other' && (
            <div className="animate-fade-in-up">
              <label className="block text-sm font-medium text-gray-700 mb-2">Prescribed Dose ({treatment.medication})</label>
              <select 
                value={treatment.dose || ''}
                onChange={(e) => handleFieldChange('dose', e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-3 border"
              >
                <option value="">Select Dose...</option>
                {treatment.medication === 'Mounjaro' && MOUNJARO_DOSES.map(d => <option key={d} value={d}>{d}</option>)}
                {treatment.medication === 'Wegovy' && WEGOVY_DOSES.map(d => <option key={d} value={d}>{d}</option>)}
                {treatment.medication === 'Ozempic' && OZEMPIC_DOSES.map(d => <option key={d} value={d}>{d}</option>)}
                {treatment.medication === 'Rybelsus' && RYBELSUS_DOSES.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          )}

          {treatment.medication === 'Other' && (
            <div className="animate-fade-in-up">
              <label className="block text-sm font-medium text-gray-700 mb-2">Specify Treatment</label>
              <input 
                type="text"
                placeholder="Enter medication name or plan..."
                value={treatment.otherDetail || ''}
                onChange={(e) => handleFieldChange('otherDetail', e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-3 border"
              />
            </div>
          )}

          <div className="border-t border-gray-100 pt-6 space-y-4">
            <div className="flex justify-between items-center">
               <label className="block text-sm font-bold text-gray-700 flex items-center gap-2">
                 <FlaskConical className="w-4 h-4 text-purple-600" /> Laboratory Requirements
               </label>
            </div>
            <button 
              onClick={() => handleFieldChange('bloodTestRequired', !treatment.bloodTestRequired)}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${treatment.bloodTestRequired ? 'bg-purple-50 border-purple-200 text-purple-700' : 'bg-white border-gray-100 text-gray-500 hover:border-gray-200'}`}
            >
              <div className="flex items-center gap-3 text-left">
                <div className={`p-2 rounded-lg ${treatment.bloodTestRequired ? 'bg-purple-200 text-purple-700' : 'bg-gray-100'}`}>
                   <FlaskConical className="w-5 h-5" />
                </div>
                <div>
                   <p className="text-sm font-bold">Weight Loss Blood Test Required</p>
                   <p className="text-[10px] opacity-70">Include Dardoc reference link in patient guide</p>
                </div>
              </div>
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${treatment.bloodTestRequired ? 'border-purple-600 bg-purple-600' : 'border-gray-300'}`}>
                {treatment.bloodTestRequired && <Check className="w-4 h-4 text-white" />}
              </div>
            </button>
          </div>

          <div className="border-t border-gray-100 pt-6">
            <div className="flex justify-between items-center mb-3">
               <label className="block text-sm font-bold text-gray-700 flex items-center gap-2">
                 <StickyNote className="w-4 h-4 text-orange-600" /> Additional Treatment Notes
               </label>
            </div>
            <textarea 
              rows={3} 
              value={treatment.notes || ''} 
              onChange={(e) => handleFieldChange('notes', e.target.value)} 
              placeholder="e.g. He needs monthly followup and weight loss program blood test."
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-3 border text-gray-700" 
            />
            <p className="mt-2 text-[10px] text-gray-400 font-medium">This note will be appended to the clinical suggestion below.</p>
          </div>

          <div className="border-t border-gray-100 pt-6">
            <div className="flex justify-between items-center mb-3">
               <label className="block text-sm font-bold text-gray-700 flex items-center gap-2">
                 <FileText className="w-4 h-4 text-medical-600" /> Clinical Suggestion (Final Output)
               </label>
               <button onClick={generateDoctorSuggestion} disabled={!treatment.medication} className="text-xs bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full border border-indigo-100 hover:bg-indigo-100 flex items-center gap-1 transition-colors">
                 <Sparkles className="w-3 h-3" /> Refresh Formatting
               </button>
            </div>
            <textarea rows={6} value={treatment.doctorSuggestions || ''} onChange={(e) => handleFieldChange('doctorSuggestions', e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-3 border font-mono text-gray-700" />
          </div>

          <div className="border-t border-gray-100 pt-6">
            <div className="flex justify-between items-center mb-3">
               <label className="block text-sm font-bold text-gray-700 flex items-center gap-2">
                 <BookOpen className="w-4 h-4 text-emerald-600" /> Patient Guide & Findings Summary (AI)
               </label>
               <button onClick={handleGenerateFullGuide} disabled={!treatment.medication || isGeneratingGuide} className="text-xs bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full border border-emerald-100 hover:bg-emerald-100 flex items-center gap-1 transition-colors">
                 {isGeneratingGuide ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                 {isGeneratingGuide ? 'Generating...' : 'Generate AI Guide'}
               </button>
            </div>
            <textarea rows={12} value={treatment.patientGuide || ''} onChange={(e) => handleFieldChange('patientGuide', e.target.value)} className="block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm p-3 border font-mono text-gray-700 leading-relaxed" />
          </div>
        </div>
      </div>

      <div className="p-5 border-t border-gray-100 bg-gray-50 flex justify-between items-center">
         <button onClick={onBack} className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2">
           <ArrowLeft className="w-4 h-4" /> Back to Intake
         </button>
         <button onClick={onComplete} disabled={!isComplete} className="bg-medical-600 text-white px-8 py-2.5 rounded-lg font-medium hover:bg-medical-700 transition-all shadow-sm flex items-center gap-2">
           <Check className="w-4 h-4" /> Finalize Record
         </button>
      </div>
    </div>
  );
};
