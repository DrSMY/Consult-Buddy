
export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other'
}

export enum ActivityLevel {
  Sedentary = 'Sedentary',
  LightlyActive = 'Lightly Active',
  ModeratelyActive = 'Moderately Active',
  VeryActive = 'Very Active'
}

export type MedicationType = 'Mounjaro' | 'Wegovy' | 'Ozempic' | 'Rybelsus' | 'Other' | '';

export interface FollowupData {
  previousDose: string;
  nextDose: string;
  sideEffects: string;
  weightLost: number | '';
  notes: string;
}

export interface TreatmentPlan {
  medication: MedicationType;
  dose?: string; // For Mounjaro/Wegovy/Rybelsus
  otherDetail?: string; // For 'Other'
  notes?: string;
  doctorSuggestions?: string; // The generated note
  patientGuide?: string; // New field for detailed patient guidance
  datePrescribed: string;
  bloodTestRequired?: boolean; // New flag for blood test
}

export interface Patient {
  id: string;
  bookingId: string;
  bookingTime: string;
  name: string;
  mobileNumber: string;
  age: number | '';
  gender: Gender;
  height: number | ''; // in cm
  weight: number | ''; // in kg
  bmi: number | null;
  bmr?: number; // Basal Metabolic Rate
  dailyCalories?: number; // TDEE
  weightLossCalories?: number; // TDEE - Deficit
  isPregnant?: boolean;
  isBreastfeeding?: boolean;
  previousGlp1Use?: boolean;
  previousMedication?: MedicationType;
  previousDose?: string;
  chronicIllnesses: string;
  medications: string;
  activityLevel: ActivityLevel;
  notes: string;
  dateAdded: string;
  aiSummary?: string;
  treatment?: TreatmentPlan;
  isFollowup?: boolean;
  followupData?: FollowupData;
}

export interface AIAnalysisResult {
  summary: string;
  eligibilityNotes: string;
}

export interface User {
  id: string;
  email: string;
  phoneNumber: string;
  name: string; // Display name (e.g. Dr. Smith)
  password?: string; // Stored locally for demo purposes
  role: 'admin' | 'doctor';
}

export const MOUNJARO_DOSES = ['2.5 mg', '5 mg', '7.5 mg', '10 mg', '12.5 mg', '15 mg'];
export const WEGOVY_DOSES = ['0.25 mg', '0.5 mg', '1 mg', '1.7 mg', '2.4 mg'];
export const OZEMPIC_DOSES = ['0.25 mg', '0.5 mg', '1 mg', '2 mg'];
export const RYBELSUS_DOSES = ['3 mg', '7 mg', '14 mg'];
