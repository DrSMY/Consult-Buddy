
import { Patient, User } from '../types';

/**
 * CloudStorage Service
 * In a production environment, you would replace these localStorage calls 
 * with fetch() requests to your API or use a SDK like Firebase/Supabase.
 */
export const CloudStorage = {
  // Simulate network latency (500ms)
  delay: (ms: number) => new Promise(resolve => setTimeout(resolve, ms)),

  /**
   * Fetches all patient records for a specific doctor from the cloud
   */
  getPatients: async (userId: string): Promise<Patient[]> => {
    await CloudStorage.delay(800);
    const key = `docslim_cloud_patients_${userId}`;
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  },

  /**
   * Persists the entire patient list to the cloud
   */
  savePatients: async (userId: string, patients: Patient[]): Promise<void> => {
    await CloudStorage.delay(400); // Simulate upload time
    const key = `docslim_cloud_patients_${userId}`;
    localStorage.setItem(key, JSON.stringify(patients));
  },

  /**
   * Updates or Creates a single patient record in the cloud
   */
  upsertPatient: async (userId: string, patient: Patient): Promise<void> => {
    const patients = await CloudStorage.getPatients(userId);
    const index = patients.findIndex(p => p.id === patient.id);
    
    if (index >= 0) {
      patients[index] = patient;
    } else {
      patients.unshift(patient);
    }
    
    await CloudStorage.savePatients(userId, patients);
  }
};
