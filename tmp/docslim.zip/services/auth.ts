import { User } from '../types';
import { generateId } from '../utils/helpers';

const USERS_KEY = 'quickwlp_users_cloud';
const SESSION_KEY = 'quickwlp_session_cloud';
const ADMIN_EMAIL = 'drsamimoha2018@gmail.com';

export const AuthService = {
  delay: (ms: number) => new Promise(resolve => setTimeout(resolve, ms)),

  getUsers: (): User[] => {
    try {
      const usersJson = localStorage.getItem(USERS_KEY);
      let users: User[] = usersJson ? JSON.parse(usersJson) : [];
      
      const adminEmail = ADMIN_EMAIL.toLowerCase();
      const hasAdmin = users.some(u => u.email.toLowerCase() === adminEmail);

      if (!hasAdmin) {
         const adminUser: User = {
           id: 'permanent-admin-id', 
           email: ADMIN_EMAIL,
           name: 'Dr Sami M. Yesuf',
           phoneNumber: '+971554110495',
           password: 'Drsami1985',
           role: 'admin'
         };
         users.push(adminUser);
         localStorage.setItem(USERS_KEY, JSON.stringify(users));
      }
      return users;
    } catch (e) {
      return [];
    }
  },

  saveUsers: (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  register: async (email: string, phoneNumber: string, name: string, password: string): Promise<{ success: boolean; message?: string; user?: User }> => {
    await AuthService.delay(1000);
    const users = AuthService.getUsers();
    
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { success: false, message: 'Email already registered.' };
    }

    const newUser: User = {
      id: generateId(),
      email,
      phoneNumber,
      name,
      password,
      role: email.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'doctor'
    };

    users.push(newUser);
    AuthService.saveUsers(users);
    AuthService.setSession(newUser);
    
    return { success: true, user: newUser };
  },

  login: async (identifier: string, password: string): Promise<{ success: boolean; message?: string; user?: User }> => {
    await AuthService.delay(800);
    const users = AuthService.getUsers();
    const cleanIdentifier = identifier.toLowerCase().trim();

    const user = users.find(u => 
      (u.email.toLowerCase() === cleanIdentifier || u.phoneNumber === cleanIdentifier) && 
      u.password === password
    );

    if (!user) {
      return { success: false, message: 'Invalid credentials.' };
    }

    AuthService.setSession(user);
    return { success: true, user };
  },

  updateProfile: async (userId: string, updates: Partial<User>): Promise<{ success: boolean; user?: User }> => {
    await AuthService.delay(600);
    const users = AuthService.getUsers();
    const index = users.findIndex(u => u.id === userId);
    
    if (index === -1) return { success: false };
    
    const updatedUser = { ...users[index], ...updates };
    
    // Ensure role is preserved or updated correctly if email changes to admin
    if (updates.email) {
      updatedUser.role = updates.email.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'doctor';
    }

    users[index] = updatedUser;
    AuthService.saveUsers(users);
    AuthService.setSession(updatedUser);
    
    return { success: true, user: updatedUser };
  },

  setSession: (user: User) => {
    const safeUser = { ...user };
    delete safeUser.password;
    localStorage.setItem(SESSION_KEY, JSON.stringify(safeUser));
  },

  getSession: (): User | null => {
    const sessionJson = localStorage.getItem(SESSION_KEY);
    return sessionJson ? JSON.parse(sessionJson) : null;
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  }
};