import { GoogleGenAI, Type } from "@google/genai";
import { Patient, Gender } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const withRetry = async <T>(fn: () => Promise<T>, maxRetries = 3): Promise<T> => {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const isRateLimit = error?.message?.includes('429') || 
                          error?.status === 429 || 
                          error?.message?.toLowerCase().includes('rate') ||
                          error?.message?.toLowerCase().includes('exhausted');
      
      if (isRateLimit && i < maxRetries - 1) {
        const delay = Math.pow(2, i + 1) * 1000; 
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
};

const patientSchema = {
  type: Type.OBJECT,
  properties: {
    bookingId: { type: Type.STRING },
    name: { type: Type.STRING },
    mobileNumber: { type: Type.STRING },
    bookingTime: { type: Type.STRING },
    age: { type: Type.NUMBER },
    gender: { type: Type.STRING, enum: [Gender.Male, Gender.Female, Gender.Other] },
    height: { type: Type.NUMBER },
    weight: { type: Type.NUMBER },
    chronicIllnesses: { type: Type.STRING },
    medications: { type: Type.STRING },
    isPregnant: { type: Type.BOOLEAN },
    isBreastfeeding: { type: Type.BOOLEAN },
  },
  required: ["gender"],
};

export const parsePatientNotes = async (notes: string): Promise<Partial<Patient>> => {
  if (!process.env.API_KEY) return {};
  try {
    return await withRetry(async () => {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Extract patient data to JSON from: "${notes}"`,
        config: { responseMimeType: "application/json", responseSchema: patientSchema },
      });
      return JSON.parse(response.text || "{}");
    });
  } catch (error) { 
    return {}; 
  }
};

export const generatePatientSummary = async (patient: Patient): Promise<string> => {
  if (!process.env.API_KEY) return "Summarizer unavailable.";
  try {
    return await withRetry(async () => {
      const treatment = patient.treatment;
      const medName = treatment?.medication === 'Other' ? (treatment.otherDetail || 'Other') : (treatment?.medication || 'None');
      const dose = treatment?.dose || '';
      const prompt = `Professional Medical Summary for ${patient.name}. BMI: ${patient.bmi?.toFixed(1)}. Rx: ${medName} ${dose}. Labs: ${treatment?.bloodTestRequired ? 'Required' : 'None'}. Provide detailed clinical bullet points.`;
      const response = await ai.models.generateContent({ model: "gemini-3-flash-preview", contents: prompt });
      return response.text || "Failed to generate summary.";
    });
  } catch (error) { return "System busy. Please try again."; }
};

export const generatePatientGuide = async (patient: Patient): Promise<string> => {
  if (!process.env.API_KEY) return "AI unavailable.";
  const treatment = patient.treatment;
  
  // Refined Logic: Medical Guide only for specified GLP-1 Brands.
  const glp1Meds = ['Mounjaro', 'Wegovy', 'Ozempic', 'Rybelsus'];
  const isGlp1Medication = !!treatment?.medication && glp1Meds.includes(treatment.medication);
  const isOral = treatment?.medication === 'Rybelsus';
  
  const medName = treatment?.medication === 'Other' ? (treatment?.otherDetail || 'Custom Program') : (treatment?.medication || 'Lifestyle Program');
  const dose = treatment?.dose || '';
  
  const salutation = patient.gender === Gender.Male ? 'Mr' : (patient.gender === Gender.Female ? 'Ms' : '');
  
  let videoLink = "";
  if (treatment?.medication === 'Mounjaro') videoLink = "https://youtube.com/shorts/S0c4uOykHOs";
  else if (treatment?.medication === 'Wegovy') videoLink = "https://youtu.be/mWSu8hZZOAs?si=mad5y_oeapGbJYno";

  const weight = Number(patient.weight) || 0;
  const protMin = Math.round(weight * 1.2);
  const protMax = Math.round(weight * 1.5);

  let prompt = "";
  if (isGlp1Medication) {
    const greeting = `Hi ${salutation} ${patient.name}, this is a guide for you to start your journey with us and take the medication as advised.`;
    
    // Customize specific sections based on whether it is Oral (Rybelsus) or Injectable
    const storageSection = isOral 
      ? "::: STORAGE INSTRUCTIONS :::\nStore in a dry place at room temperature (below 30°C). Keep in original blister pack until used to protect from moisture."
      : "::: STORAGE INSTRUCTIONS :::\nRefrigeration (2-8°C), room temp limits (30°C for 21 days), do not freeze, protect from light.";
    
    const adminSection = isOral
      ? `::: HOW TO TAKE :::\nTake one tablet daily on an empty stomach. Swallow whole with a small sip of water (no more than 4oz/120ml). Wait at least 30 minutes before your first food, drink, or other oral medications.`
      : `::: HOW TO INJECT :::\nStep-by-step instructions for ${medName}. Rotate sites. ${videoLink ? `Include this video link: ${videoLink}` : ""}`;

    prompt = `Create a professional Patient-Centered Care Guide for ${patient.name} starting ${medName} ${dose}.
CRITICAL INSTRUCTION: Start exactly with: "${greeting}"

Follow this structure strictly:

::: INTRODUCTION :::
Purpose of guide, medication name (${medName} ${dose}), explanation of GLP-1/GIP receptor agonists (appetite reduction, delayed gastric emptying, metabolism), and the medical journey ahead.

::: PATIENT SUMMARY :::
Weight: ${patient.weight}kg, Height: ${patient.height}cm, BMI: ${patient.bmi?.toFixed(1)}.
Estimated Daily Calories for Weight Loss: ${patient.weightLossCalories ? Math.round(patient.weightLossCalories) : '---'} kcal/day.

${storageSection}

${adminSection}

::: NUTRITION & DIET STRUCTURE :::
Protein Target: ${protMin}–${protMax} g/day. 
Hydration: 2–3 liters/day.
Macronutrient distribution:
• Protein: 40–50%
• Fiber-rich whole foods: 40–50%
• Carbohydrates: <20% (low-GI grains)

::: COMMON SIDE EFFECTS & MANAGEMENT :::
Nausea, constipation, diarrhea, heartburn with home management tips.

::: RED-FLAG SYMPTOMS :::
Severe abdominal pain, persistent vomiting, dehydration. Advise when to seek urgent care.

::: FOLLOW-UP PLAN :::
Mandatory review after 4th dose. Assess tolerance and response.
${treatment?.bloodTestRequired ? "REQUIRED: Complete Weight Loss Blood Test (https://www.dardoc.com/dubai/lab-test/weight-loss-blood-test)" : ""}

Sign as:
Dr Sami M. Yesuf
SCOPE Certified Physician`;
  } else {
    // Lifestyle only prompt - Used for 'Other' or 'Lifestyle'
    const lifestyleGreeting = `Hi ${salutation} ${patient.name}, this is your personalized guide for a healthy lifestyle and sustainable weight management journey with us${treatment?.medication === 'Other' ? ` alongside your ${treatment.otherDetail} treatment` : ''}.`;
    
    prompt = `Create a professional Weight Loss & Lifestyle Guide for ${patient.name}.
CRITICAL INSTRUCTION: Start with: "${lifestyleGreeting}"

Focus strictly on lifestyle modifications:

::: NUTRITION & DIETARY ADVICE :::
Provide a comprehensive high protein nutrition plan.
Target Protein: ${protMin}–${protMax} g/day.
Macro Breakdown: 
• Protein: 40-50%
• Fiber-rich whole foods: 40-50%
• Carbohydrates: <20% (Whole grains, low-GI).

::: PHYSICAL ACTIVITY PLAN :::
Activity Level: ${patient.activityLevel}. Provide specific cardio and strength training recommendations based on their weight (${patient.weight}kg).

::: CONSISTENCY & MINDSET :::
Strategies for habit formation, tracking progress, and overcoming weight-loss plateaus.

::: HYDRATION & RECOVERY :::
Guidelines for water intake and the importance of sleep in metabolism.

::: FOLLOW-UP PLAN :::
Regular check-ins (monthly) to monitor progress.
${treatment?.bloodTestRequired ? "Note: Please complete the required lab test: https://www.dardoc.com/dubai/lab-test/weight-loss-blood-test" : ""}

Sign as:
Dr Sami M. Yesuf
SCOPE Certified Physician`;
  }

  try {
    return await withRetry(async () => {
      const response = await ai.models.generateContent({ model: "gemini-3-flash-preview", contents: prompt });
      return response.text || "Failed to generate guide.";
    });
  } catch (error) { return "Rate limit exceeded. Please try again."; }
};
